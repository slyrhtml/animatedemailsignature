# DigitxlLink Signature Hosting Bundle

Upload the `signature/` folder to the public host for:

`https://cdn.thedigitxllink.com/signature/`

After upload, these URLs should resolve:

- `https://cdn.thedigitxllink.com/signature/card-bg-animated.gif`
- `https://cdn.thedigitxllink.com/signature/card-bg-static.png`
- `https://cdn.thedigitxllink.com/signature/contact-text-animated.gif`
- `https://cdn.thedigitxllink.com/signature/facebook-icon-animated.gif`
- `https://cdn.thedigitxllink.com/signature/insta-icon-animated.gif`
- `https://cdn.thedigitxllink.com/signature/linkedin-icon-animated.gif`
- `https://cdn.thedigitxllink.com/signature/logo-animated.gif`
- `https://cdn.thedigitxllink.com/signature/profile-animated.gif`
- `https://cdn.thedigitxllink.com/signature/web-icon-animated.gif`
- `https://cdn.thedigitxllink.com/signature/youtube-icon-animated.gif`

Use `signature.html` as the email signature markup after the files are live.
